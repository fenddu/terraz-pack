#version 330

layout(std140) uniform LightmapInfo {
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float BossOverlayWorldDarkeningFactor;
    float BrightnessFactor;
    vec3 BlockLightTint;
    vec3 SkyLightColor;
    vec3 AmbientColor;
    vec3 NightVisionColor;
} lightmapInfo;

in vec2 texCoord;

out vec4 fragColor;

// ===== TerraZ: настройки тьмы =====
// Ниже этой яркости всё уходит в черноту (0.0 = как в ванилле)
const float TZ_BLACK = 0.05;
// С этой яркости картинка уже обычная
const float TZ_FULL  = 0.40;
// Сколько лунного света остаётся глубокой ночью (1.0 = как в ванилле)
const float TZ_NIGHT_SKY = 0.30;
// Игнорировать ползунок яркости игрока (1.0 = полностью)
const float TZ_IGNORE_GAMMA = 1.0;
// ==================================

float get_brightness(float level) {
    return level / (4.0 - 3.0 * level);
}

vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

float parabolicMixFactor(float level) {
    return (2.0 * level - 1.0) * (2.0 * level - 1.0);
}

void main() {
    // Calculate block and sky brightness levels based on texture coordinates
    float block_level = floor(texCoord.x * 16) / 15;
    float sky_level = floor(texCoord.y * 16) / 15;

    float block_brightness = get_brightness(block_level) * lightmapInfo.BlockFactor;
    float sky_brightness = get_brightness(sky_level) * lightmapInfo.SkyFactor;

    // Calculate ambient color with or without night vision
    vec3 nightVisionColor = lightmapInfo.NightVisionColor * lightmapInfo.NightVisionFactor;
    vec3 color = max(lightmapInfo.AmbientColor, nightVisionColor);

    // Add sky light
    // TerraZ: ночью небесный свет сильно приглушается
    vec3 tzSkyFull = lightmapInfo.SkyLightColor * lightmapInfo.SkyFactor;
    float tzDay = smoothstep(0.30, 0.80, max(max(tzSkyFull.r, tzSkyFull.g), tzSkyFull.b));
    float tzSkyMul = (lightmapInfo.NightVisionFactor > 0.0) ? 1.0 : mix(TZ_NIGHT_SKY, 1.0, tzDay);
    color += lightmapInfo.SkyLightColor * sky_brightness * tzSkyMul;

    // Add block light
    vec3 BlockLightColor = mix(lightmapInfo.BlockLightTint, vec3(1.0), 0.9 * parabolicMixFactor(block_level));
    color += BlockLightColor * block_brightness;

    // Apply boss overlay darkening effect
    color = mix(color, color * vec3(0.7, 0.6, 0.6), lightmapInfo.BossOverlayWorldDarkeningFactor);

    // Apply darkness effect scale
    color = color - vec3(lightmapInfo.DarknessScale);

    // Apply brightness
    color = clamp(color, 0.0, 1.0);

    // TerraZ: ночное зрение (персонал) обходит тьму
    if (lightmapInfo.NightVisionFactor <= 0.0) {
        float lum = max(max(color.r, color.g), color.b);
        color *= smoothstep(TZ_BLACK, TZ_FULL, lum);
    }

    // TerraZ: ползунок яркости игрока почти не влияет
    float tzBrightness = lightmapInfo.BrightnessFactor * (1.0 - TZ_IGNORE_GAMMA);
    if (lightmapInfo.NightVisionFactor > 0.0) tzBrightness = lightmapInfo.BrightnessFactor;
    vec3 notGamma = notGamma(color);
    color = mix(color, notGamma, tzBrightness);

    fragColor = vec4(color, 1.0);
}
